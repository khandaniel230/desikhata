
// Demo tab functionality
document.addEventListener('DOMContentLoaded', function() {
    // Demo tabs
    const demoButtons = document.querySelectorAll('.demo-tab');
    const demoPanels = document.querySelectorAll('.demo-panel')

    demoButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetDemo = button.getAttribute('data-demo')

            // Update active button
            demoButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active')

            // Show target panel
            demoPanels.forEach(panel => {
                panel.classList.remove('active');
                if (panel.id === `${targetDemo}-demo`) {
                    panel.classList.add('active');
                }
            });
        });
    })

    // BMI Calculator functionality
    const bmiCalculateBtn = document.querySelector('#bmi-demo .calculate-btn');
    if (bmiCalculateBtn) {
        bmiCalculateBtn.addEventListener('click', calculateBMI);
    }

function calculateBMI() {
        const height = parseFloat(document.getElementById('height').value);
        const weight = parseFloat(document.getElementById('weight').value)

        if (isNaN(height) || isNaN(weight) || height <= 0 || weight <= 0) {
            alert('Please enter valid height and weight values.');
            return;
        }

        // Calculate BMI (weight in kg / (height in m)^2)
        const heightInMeters = height / 100;
        const bmi = weight / (heightInMeters * heightInMeters);
        const roundedBMI = bmi.toFixed(1)

        // Determine category
        let category = '';
        if (bmi < 18.5) {
            category = 'Underweight';
        } else if (bmi < 25) {
            category = 'Normal weight';
        } else if (bmi < 30) {
            category = 'Overweight';
        } else {
            category = 'Obese';
        }

        // Update results
        document.getElementById('bmi-result').textContent = roundedBMI;
        document.getElementById('bmi-category').textContent = `Category: ${category}`;
    }

    // Currency Converter functionality
    const currencyCalculateBtn = document.querySelector('#currency-demo .calculate-btn');
    if (currencyCalculateBtn) {
        currencyCalculateBtn.addEventListener('click', convertCurrency);
    }

function convertCurrency() {
        // Mock conversion rates (in a real app, you'd fetch these from an API)
        const rates = {
            USD: { EUR: 0.85, GBP: 0.73, JPY: 110.5 },
            EUR: { USD: 1.18, GBP: 0.86, JPY: 130.2 },
            GBP: { USD: 1.37, EUR: 1.16, JPY: 151.3 },
            JPY: { USD: 0.0091, EUR: 0.0077, GBP: 0.0066 }
        }

        const amount = parseFloat(document.getElementById('amount').value);
        const fromCurrency = document.getElementById('from-currency').value;
        const toCurrency = document.getElementById('to-currency').value

        if (isNaN(amount) || amount <= 0) {
            alert('Please enter a valid amount.');
            return;
        }

        if (fromCurrency === toCurrency) {
            document.getElementById('conversion-result').textContent = amount.toFixed(2) + ' ' + toCurrency;
            document.getElementById('conversion-rate').textContent = 'Same currency - no conversion needed';
            return;
        }

        const rate = rates[fromCurrency][toCurrency];
        const convertedAmount = amount * rate

        document.getElementById('conversion-result').textContent = convertedAmount.toFixed(2) + ' ' + toCurrency;
        document.getElementById('conversion-rate').textContent = `1 ${fromCurrency} = ${rate} ${toCurrency}`;
    }

    // Loan Calculator functionality
    const loanCalculateBtn = document.querySelector('#loan-demo .calculate-btn');
    if (loanCalculateBtn) {
        loanCalculateBtn.addEventListener('click', calculateLoan);
    }

function calculateLoan() {
        const loanAmount = parseFloat(document.getElementById('loan-amount').value);
        const interestRate = parseFloat(document.getElementById('interest-rate').value);
        const loanTerm = parseFloat(document.getElementById('loan-term').value)

        if (isNaN(loanAmount) || isNaN(interestRate) || isNaN(loanTerm) || 
            loanAmount <= 0 || interestRate <= 0 || loanTerm <= 0) {
            alert('Please enter valid loan details.');
            return;
        }

        // Calculate monthly payment
        const monthlyRate = interestRate / 100 / 12;
        const numberOfPayments = loanTerm * 12;
        const monthlyPayment = (loanAmount * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -numberOfPayments))

        // Calculate total interest
        const totalPayment = monthlyPayment * numberOfPayments;
        const totalInterest = totalPayment - loanAmount

        document.getElementById('payment-result').textContent = '$' + monthlyPayment.toFixed(2);
        document.getElementById('total-interest').textContent = `Total interest: $${totalInterest.toFixed(2)} over ${numberOfPayments} payments`;
    }
});
